
if(typeof(tpl_public) == 'undefined'){tpl_public="";}
document.write('<script type="text/javascript" src="'+tpl_public+'/js/calendar/calendar.js"></script>');
document.write('<script type="text/javascript" src="'+tpl_public+'/js/calendar/lang/en.js"></script>');
document.write('<link rel="stylesheet" type="text/css" href="'+tpl_public+'/js/calendar/jscal2.css" />');
document.write('<link rel="stylesheet" type="text/css" href="'+tpl_public+'/js/calendar/border-radius.css" />');
document.write('<link rel="stylesheet" type="text/css" href="'+tpl_public+'/js/calendar/win2k.css" />');
